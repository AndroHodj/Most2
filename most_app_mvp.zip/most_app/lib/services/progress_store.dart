import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';

class ProgressStore {
  static const _key = 'most_progress_v1';
  final SharedPreferences prefs;
  ProgressStore(this.prefs);

  Map<String, dynamic> get data {
    final raw = prefs.getString(_key);
    if (raw == null) return {'completedDays': <int>[], 'knownWords': <String>[], 'streak': 0};
    try { return jsonDecode(raw) as Map<String, dynamic>; }
    catch (_) { return {'completedDays': <int>[], 'knownWords': <String>[], 'streak': 0}; }
  }

  Future<void> _save(Map<String, dynamic> next) async {
    await prefs.setString(_key, jsonEncode(next));
    await syncIfSignedIn(next);
  }

  List<int> get completedDays => (data['completedDays'] as List? ?? []).map((e) => e as int).toList();
  List<String> get knownWords => (data['knownWords'] as List? ?? []).map((e) => e.toString()).toList();
  int get streak => data['streak'] as int? ?? 0;

  Future<void> completeDay(int day) async {
    final next = Map<String, dynamic>.from(data);
    final days = completedDays.toSet()..add(day);
    next['completedDays'] = days.toList()..sort();
    next['lastActivity'] = DateTime.now().toIso8601String();
    next['streak'] = streak == 0 ? 1 : streak;
    await _save(next);
  }

  Future<void> addKnownWord(String phrase) async {
    final next = Map<String, dynamic>.from(data);
    final words = knownWords.toSet()..add(phrase);
    next['knownWords'] = words.toList();
    await _save(next);
  }

  Future<void> syncIfSignedIn(Map<String, dynamic> payload) async {
    try {
      final client = Supabase.instance.client;
      final user = client.auth.currentUser;
      if (user == null) return;
      await client.from('user_progress').upsert({
        'user_id': user.id,
        'progress': payload,
        'updated_at': DateTime.now().toUtc().toIso8601String(),
      });
    } catch (_) {
      // Local progress remains safe; sync can be retried when the app reconnects.
    }
  }

  Future<void> restoreFromCloud() async {
    try {
      final client = Supabase.instance.client;
      final user = client.auth.currentUser;
      if (user == null) return;
      final row = await client.from('user_progress').select('progress').eq('user_id', user.id).maybeSingle();
      if (row != null && row['progress'] is Map) {
        final cloud = Map<String, dynamic>.from(row['progress'] as Map);
        final local = data;
        final merged = <String, dynamic>{...cloud, ...local};
        final days = <int>{
          ...(cloud['completedDays'] as List? ?? []).whereType<num>().map((e) => e.toInt()),
          ...(local['completedDays'] as List? ?? []).whereType<num>().map((e) => e.toInt()),
        }.toList()..sort();
        final words = <String>{
          ...(cloud['knownWords'] as List? ?? []).map((e) => e.toString()),
          ...(local['knownWords'] as List? ?? []).map((e) => e.toString()),
        }.toList();
        merged['completedDays'] = days;
        merged['knownWords'] = words;
        await prefs.setString(_key, jsonEncode(merged));
        await syncIfSignedIn(merged);
      } else {
        await syncIfSignedIn(data);
      }
    } catch (_) {
      // Offline or not configured: continue with local data.
    }
  }
}
