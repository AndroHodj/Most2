class Lesson {
  final int day;
  final String title;
  final String subtitle;
  final String focus;
  final int minutes;
  final List<String> phrases;

  const Lesson({required this.day, required this.title, required this.subtitle,
    required this.focus, required this.minutes, required this.phrases});

  static const starter = <Lesson>[
    Lesson(day: 1, title: 'Знакомство', subtitle: 'Представься и расскажи о себе', focus: 'I am / My name is', minutes: 20, phrases: ['My name is…', 'I am from…', 'Nice to meet you.', 'What do you do?']),
    Lesson(day: 2, title: 'Откуда ты и где живёшь', subtitle: 'Страны, города и личная информация', focus: 'I live / I have', minutes: 20, phrases: ['I live in…', 'I have…', 'Where do you live?', 'I am from Russia.']),
    Lesson(day: 3, title: 'Что тебе нравится', subtitle: 'Интересы и предпочтения', focus: 'I like / I don’t like', minutes: 20, phrases: ['I like…', 'I enjoy…', 'I don’t like…', 'In my free time…']),
    Lesson(day: 4, title: 'Задаём вопросы', subtitle: 'Начни поддерживать диалог', focus: 'Are you…? / Do you…?', minutes: 20, phrases: ['Are you…?', 'Do you work…?', 'Where are you from?', 'Could you repeat that?']),
    Lesson(day: 5, title: 'Мой обычный день', subtitle: 'Расскажи о повседневной жизни', focus: 'Present Simple', minutes: 20, phrases: ['I usually…', 'I start work at…', 'I finish at…', 'After work…']),
    Lesson(day: 6, title: 'Первый разговор', subtitle: 'Объедини изученные конструкции', focus: 'Conversation practice', minutes: 20, phrases: ['Tell me about yourself.', 'What do you do?', 'What do you like doing?', 'That sounds interesting.']),
    Lesson(day: 7, title: 'Повторение и проверка', subtitle: 'Закрепи материал первой недели', focus: 'Review', minutes: 15, phrases: ['I am…', 'I live…', 'I work…', 'I like…']),
  ];
}
