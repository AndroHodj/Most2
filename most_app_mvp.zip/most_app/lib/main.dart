import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:supabase_flutter/supabase_flutter.dart';
import 'models/lesson.dart';
import 'services/progress_store.dart';

const navy = Color(0xFF14243A);
const teal = Color(0xFF1A9A91);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  // Add Supabase URL and anon key with --dart-define when cloud sync is configured.
  const url = String.fromEnvironment('SUPABASE_URL');
  const anon = String.fromEnvironment('SUPABASE_ANON_KEY');
  if (url.isNotEmpty && anon.isNotEmpty) {
    await Supabase.initialize(url: url, anonKey: anon);
  }
  final prefs = await SharedPreferences.getInstance();
  runApp(MostApp(store: ProgressStore(prefs)));
}

class MostApp extends StatelessWidget {
  final ProgressStore store;
  const MostApp({super.key, required this.store});
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'МОСТ — английский', debugShowCheckedModeBanner: false,
    theme: ThemeData(colorScheme: ColorScheme.fromSeed(seedColor: teal, brightness: Brightness.light), scaffoldBackgroundColor: const Color(0xFFF5F7FA), useMaterial3: true, appBarTheme: const AppBarTheme(backgroundColor: Color(0xFFF5F7FA), foregroundColor: navy, elevation: 0)),
    home: HomeShell(store: store),
  );
}

class HomeShell extends StatefulWidget {
  final ProgressStore store;
  const HomeShell({super.key, required this.store});
  @override State<HomeShell> createState() => _HomeShellState();
}
class _HomeShellState extends State<HomeShell> {
  int tab = 0;
  @override Widget build(BuildContext context) {
    final pages = [Dashboard(store: widget.store), LessonsPage(store: widget.store), VocabularyPage(store: widget.store), ProgressPage(store: widget.store), ProfilePage(store: widget.store)];
    return Scaffold(body: SafeArea(child: pages[tab]), bottomNavigationBar: NavigationBar(selectedIndex: tab, onDestinationSelected: (v) => setState(() => tab = v), destinations: const [NavigationDestination(icon: Icon(Icons.home_outlined), label: 'Главная'), NavigationDestination(icon: Icon(Icons.menu_book_outlined), label: 'Уроки'), NavigationDestination(icon: Icon(Icons.style_outlined), label: 'Слова'), NavigationDestination(icon: Icon(Icons.insights_outlined), label: 'Прогресс'), NavigationDestination(icon: Icon(Icons.person_outline), label: 'Профиль')]));
  }
}

class Dashboard extends StatelessWidget {
  final ProgressStore store;
  const Dashboard({super.key, required this.store});
  @override Widget build(BuildContext context) {
    final done = store.completedDays.length;
    final next = (done + 1).clamp(1, 7);
    return ListView(padding: const EdgeInsets.all(20), children: [
      const Text('МОСТ', style: TextStyle(fontSize: 15, fontWeight: FontWeight.w800, letterSpacing: 3, color: teal)),
      const SizedBox(height: 8), const Text('Английский,\nкоторый начинает говорить', style: TextStyle(fontSize: 29, height: 1.15, fontWeight: FontWeight.w800, color: navy)),
      const SizedBox(height: 22),
      Container(padding: const EdgeInsets.all(20), decoration: BoxDecoration(color: navy, borderRadius: BorderRadius.circular(24)), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [const Text('ТВОЯ ЦЕЛЬ СЕГОДНЯ', style: TextStyle(color: Colors.white70, fontSize: 11, letterSpacing: 1.2)), const SizedBox(height: 10), Text('20 минут английского', style: const TextStyle(color: Colors.white, fontSize: 22, fontWeight: FontWeight.bold)), const SizedBox(height: 8), Text('Урок $next · ${Lesson.starter[next-1].title}', style: const TextStyle(color: Colors.white70)), const SizedBox(height: 16), ClipRRect(borderRadius: BorderRadius.circular(10), child: LinearProgressIndicator(value: done/7, minHeight: 8, backgroundColor: Colors.white24, color: const Color(0xFF67D6C8))), const SizedBox(height: 8), Text('$done из 7 уроков первой недели', style: const TextStyle(color: Colors.white70, fontSize: 12)), const SizedBox(height: 14), FilledButton(onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LessonDetail(store: store, lesson: Lesson.starter[next-1]))), child: const Text('Продолжить обучение'))])),
      const SizedBox(height: 22), const Text('Сегодня потренируем', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: navy)), const SizedBox(height: 12),
      const FeatureTile(icon: Icons.record_voice_over, title: 'Говорение', detail: 'Собери ответ из знакомых фраз'), const FeatureTile(icon: Icons.psychology_alt_outlined, title: 'Словарный запас', detail: 'Учись вспоминать слова без подсказки'), const FeatureTile(icon: Icons.headphones_outlined, title: 'Аудирование', detail: 'Короткий диалог с проверкой понимания'),
    ]);
  }
}

class FeatureTile extends StatelessWidget { final IconData icon; final String title, detail; const FeatureTile({super.key, required this.icon, required this.title, required this.detail}); @override Widget build(BuildContext context) => Card(elevation: 0, margin: const EdgeInsets.only(bottom: 8), child: ListTile(leading: CircleAvatar(backgroundColor: teal.withOpacity(.12), child: Icon(icon, color: teal)), title: Text(title, style: const TextStyle(fontWeight: FontWeight.w700)), subtitle: Text(detail))); }

class LessonsPage extends StatelessWidget {
  final ProgressStore store; const LessonsPage({super.key, required this.store});
  @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [const Text('Программа', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: navy)), const SizedBox(height: 6), const Text('Первая неделя · Возвращение английского'), const SizedBox(height: 16), ...Lesson.starter.map((l) { final complete = store.completedDays.contains(l.day); return Card(elevation: 0, child: ListTile(leading: CircleAvatar(backgroundColor: complete ? teal : navy.withOpacity(.08), child: complete ? const Icon(Icons.check, color: Colors.white) : Text('${l.day}', style: const TextStyle(color: navy))), title: Text(l.title, style: const TextStyle(fontWeight: FontWeight.bold)), subtitle: Text('${l.subtitle}\n${l.minutes} минут · ${l.focus}'), isThreeLine: true, trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => LessonDetail(store: store, lesson: l))))); })]);
}

class LessonDetail extends StatefulWidget { final ProgressStore store; final Lesson lesson; const LessonDetail({super.key, required this.store, required this.lesson}); @override State<LessonDetail> createState() => _LessonDetailState(); }
class _LessonDetailState extends State<LessonDetail> {
  final answer = TextEditingController(); bool checked = false;
  @override void dispose() { answer.dispose(); super.dispose(); }
  @override Widget build(BuildContext context) { final l = widget.lesson; return Scaffold(appBar: AppBar(title: Text('День ${l.day}')), body: ListView(padding: const EdgeInsets.all(20), children: [Text(l.title, style: const TextStyle(fontSize: 27, fontWeight: FontWeight.bold, color: navy)), const SizedBox(height: 6), Text(l.subtitle), const SizedBox(height: 18), const Text('1. Запомни полезные выражения', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 8), ...l.phrases.map((p) => Card(elevation: 0, child: ListTile(title: Text(p), trailing: IconButton(icon: const Icon(Icons.bookmark_add_outlined), onPressed: () async { await widget.store.addKnownWord(p); if (context.mounted) ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Добавлено в твой словарь'))); })))), const SizedBox(height: 16), const Text('2. Скажи или напиши свой ответ', style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), const SizedBox(height: 6), const Text('Используй минимум две фразы из урока. Не бойся ошибок — они помогут выбрать следующие упражнения.'), const SizedBox(height: 8), TextField(controller: answer, minLines: 3, maxLines: 5, decoration: const InputDecoration(border: OutlineInputBorder(), hintText: 'Write your answer in English…')), const SizedBox(height: 12), FilledButton(onPressed: answer.text.trim().isEmpty ? null : () => setState(() => checked = true), child: const Text('Проверить готовность ответа')), if (checked) const Padding(padding: EdgeInsets.only(top: 10), child: Text('Отлично! Сравни ответ с выражениями урока. В следующей версии подключим автоматическую проверку грамматики и речи.', style: TextStyle(color: teal))), const SizedBox(height: 12), OutlinedButton.icon(onPressed: () async { await widget.store.completeDay(l.day); if (context.mounted) { ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Урок отмечен как завершённый'))); Navigator.pop(context); } }, icon: const Icon(Icons.check_circle_outline), label: const Text('Завершить урок'))])); }
}

class VocabularyPage extends StatefulWidget { final ProgressStore store; const VocabularyPage({super.key, required this.store}); @override State<VocabularyPage> createState() => _VocabularyPageState(); }
class _VocabularyPageState extends State<VocabularyPage> { @override Widget build(BuildContext context) { final words = widget.store.knownWords; return ListView(padding: const EdgeInsets.all(20), children: [const Text('Мой словарь', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: navy)), const Text('Фразы, которые ты хочешь активно использовать.'), const SizedBox(height: 16), if (words.isEmpty) const Card(elevation: 0, child: Padding(padding: EdgeInsets.all(18), child: Text('Пока словарь пуст. Открой урок и добавь первые выражения кнопкой закладки.'))) else ...words.map((w) => Card(elevation: 0, child: ListTile(leading: const Icon(Icons.bookmark, color: teal), title: Text(w))))]); } }

class ProgressPage extends StatelessWidget { final ProgressStore store; const ProgressPage({super.key, required this.store}); @override Widget build(BuildContext context) { final done = store.completedDays.length; return ListView(padding: const EdgeInsets.all(20), children: [const Text('Твой прогресс', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: navy)), const SizedBox(height: 18), Card(elevation: 0, child: Padding(padding: const EdgeInsets.all(20), child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [Text('$done / 7', style: const TextStyle(fontSize: 36, fontWeight: FontWeight.bold, color: teal)), const Text('уроков первой недели завершено'), const SizedBox(height: 12), LinearProgressIndicator(value: done/7, minHeight: 9)]))), Card(elevation: 0, child: ListTile(leading: const Icon(Icons.style, color: teal), title: Text('${store.knownWords.length}'), subtitle: const Text('выражений в словаре'))), const SizedBox(height: 12), const Text('МОСТ отслеживает не только количество пройденных уроков, но и способность самостоятельно использовать лексику. В следующих версиях добавим отдельные показатели говорения, аудирования, чтения, письма и грамматики.')]); } }

class ProfilePage extends StatelessWidget { final ProgressStore store; const ProfilePage({super.key, required this.store}); @override Widget build(BuildContext context) => ListView(padding: const EdgeInsets.all(20), children: [const Text('Профиль', style: TextStyle(fontSize: 28, fontWeight: FontWeight.bold, color: navy)), const SizedBox(height: 18), const CircleAvatar(radius: 34, backgroundColor: Color(0xFFDAF1EE), child: Icon(Icons.person, size: 38, color: teal)), const SizedBox(height: 12), const Center(child: Text('Ученик МОСТ', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold))), const SizedBox(height: 20), const Card(elevation: 0, child: ListTile(leading: Icon(Icons.timer_outlined), title: Text('Ежедневная цель'), subtitle: Text('До 20 минут'))), Card(elevation: 0, child: ListTile(leading: const Icon(Icons.cloud_sync_outlined), title: const Text('Аккаунт и синхронизация'), subtitle: const Text('Локально без регистрации или облако после входа'), trailing: const Icon(Icons.chevron_right), onTap: () => Navigator.push(context, MaterialPageRoute(builder: (_) => AuthPage(store: store))))), const Card(elevation: 0, child: ListTile(leading: Icon(Icons.info_outline), title: Text('Версия приложения'), subtitle: Text('MVP 0.1.0')))]); }


class AuthPage extends StatefulWidget {
  final ProgressStore store;
  const AuthPage({super.key, required this.store});
  @override State<AuthPage> createState() => _AuthPageState();
}
class _AuthPageState extends State<AuthPage> {
  final email = TextEditingController();
  final password = TextEditingController();
  bool busy = false;
  String message = 'Войди или создай аккаунт, чтобы синхронизировать прогресс.';
  @override void dispose() { email.dispose(); password.dispose(); super.dispose(); }
  Future<void> auth(bool create) async {
    setState(() { busy = true; message = 'Подключаем аккаунт…'; });
    try {
      final client = Supabase.instance.client;
      if (create) { await client.auth.signUp(email: email.text.trim(), password: password.text); }
      else { await client.auth.signInWithPassword(email: email.text.trim(), password: password.text); }
      await widget.store.restoreFromCloud();
      if (mounted) setState(() => message = client.auth.currentUser == null ? 'Проверь почту, чтобы подтвердить регистрацию.' : 'Аккаунт подключён. Прогресс синхронизирован.');
    } catch (e) { if (mounted) setState(() => message = 'Не удалось подключиться. Проверь настройки Supabase и данные входа.'); }
    finally { if (mounted) setState(() => busy = false); }
  }
  @override Widget build(BuildContext context) => Scaffold(appBar: AppBar(title: const Text('Аккаунт МОСТ')), body: ListView(padding: const EdgeInsets.all(20), children: [const Icon(Icons.cloud_sync_outlined, size: 54, color: teal), const SizedBox(height: 14), const Text('Сохрани свой прогресс', textAlign: TextAlign.center, style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold, color: navy)), const SizedBox(height: 8), Text(message, textAlign: TextAlign.center), const SizedBox(height: 20), TextField(controller: email, keyboardType: TextInputType.emailAddress, decoration: const InputDecoration(labelText: 'Email', border: OutlineInputBorder())), const SizedBox(height: 12), TextField(controller: password, obscureText: true, decoration: const InputDecoration(labelText: 'Пароль', border: OutlineInputBorder())), const SizedBox(height: 16), FilledButton(onPressed: busy ? null : () => auth(false), child: const Text('Войти')), OutlinedButton(onPressed: busy ? null : () => auth(true), child: const Text('Создать аккаунт')), const SizedBox(height: 12), const Text('Без аккаунта приложение продолжает сохранять результаты на этом устройстве.', textAlign: TextAlign.center, style: TextStyle(color: Colors.black54))]));
}
